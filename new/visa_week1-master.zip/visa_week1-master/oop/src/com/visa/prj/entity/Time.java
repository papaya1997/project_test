package com.visa.prj.entity;

public class Time {
	private int hrs;
	private int min;
	public Time(int hrs, int min) {
			this.hrs = hrs;
			this.min = min;
	}
	public static Time addTime(Time t1, Time t2) {
		return null;
	}
	public int getHours() {
		return 0;
	}
	public int getMin() {
		return 0;
	}
	public Time addTime(Time t2) {
		return null;
	}

}
